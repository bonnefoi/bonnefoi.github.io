/*
* TP 3 - Shared memory and synchronisation
* --------------------------
* Reduction
*
* File: reference.cpp
*/

// DO NOT MODIFY THIS FILE !!!

#include "reference.hpp"
#include <algorithm>

unsigned int maxRef( const unsigned int n, const unsigned int *const a ) {
	unsigned int res = a[0];

	for ( unsigned int i = 1; i < n; ++i ) {
		res = std::max<unsigned int>( res, a[i] );
	}

	return res;
}


