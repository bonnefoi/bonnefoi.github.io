/*
* TP 3 - Shared memory and synchronisation
* --------------------------
* Reduction
*
* File: reference.hpp
*/

// DO NOT MODIFY THIS FILE !!!

#ifndef __REFERENCE_HPP
#define __REFERENCE_HPP

unsigned int maxRef( const unsigned int n, const unsigned int *const a );

#endif

