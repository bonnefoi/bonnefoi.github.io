/*
* TP 3 - Shared memory and synchronisation
* --------------------------
* Reduction
*
* File: student.hpp
*/

#ifndef __STUDENT_HPP
#define __STUDENT_HPP

#include "reference.hpp"
#include "utils/common.hpp"
#include "utils/chronoCPU.hpp"
#include "utils/chronoGPU.hpp"

// ==================================================== V0
__global__
void maxReduce_v0( const unsigned int n, const unsigned int *const dev_array, unsigned int *const dev_partialMax );

// ==================================================== V1
#define V1_NOT_IMPLEMENTED
__global__
void maxReduce_v1( const unsigned int n, const unsigned int *const dev_array, unsigned int *const dev_partialMax );

// ==================================================== V2
#define V2_NOT_IMPLEMENTED
__global__
void maxReduce_v2( const unsigned int n, const unsigned int *const dev_array, unsigned int *const dev_partialMax );


// ==================================================== V3
#define V3_NOT_IMPLEMENTED
__global__
void maxReduce_v3( const unsigned int n, const unsigned int *const dev_array, unsigned int *const dev_partialMax );

// ==================================================== Kernels launches
template<int numKernel> __host__
float2 launchKernel( const unsigned int n, const unsigned int *const dev_array, unsigned int &res ) {
	float2 times;
	
	// Set grid and block dimensions
	unsigned int dimBlock;
	unsigned int dimGrid;
	switch ( numKernel ) {
	case 0: // V0
		//==========================================================
		//					TODO Exercise 2
		//==========================================================
		dimBlock = 256;
		dimGrid = 32768;
		break;
	case 1: // V1
		//==========================================================
		//                       TODO 
		//==========================================================
		break;
	case 2: // V2
		//==========================================================
		//                       TODO 
		//==========================================================
		break;
	case 3: // V3
		//==========================================================
		//                       TODO 
		//==========================================================
		break;
	default: 
		break;
	}
	verifyDimGridBlock( dimGrid, dimBlock, n ); // Are you reasonable ?
	
	// Allocate arrays (on host and device) for partial result
	unsigned int *host_partialMax	= new unsigned int[dimGrid];
	size_t sizePartial		= dimGrid  * sizeof(unsigned int);
	size_t sizeSMem			= dimBlock * sizeof(unsigned int);

	std::cout << "Computing on " << dimGrid << " block(s) and " 
				<< dimBlock << " thread(s) - shared memory size = " 
				<< sizeSMem << std::endl;

	unsigned int *dev_partialMax;
	HANDLE_ERROR( cudaMalloc( (void**) &dev_partialMax, sizePartial ) );
    HANDLE_ERROR( cudaMemcpy( dev_partialMax, dev_array, sizePartial, cudaMemcpyDeviceToDevice ) );

	ChronoGPU chrGPU;
	chrGPU.start();
	int loop = 100;
	for (int i = 0; i < loop; ++i ) {
	switch ( numKernel ) {
	// Launch kernel
	case 0: // Exercice 1
		maxReduce_v0<<<dimGrid, dimBlock, sizeSMem>>>( n, dev_array, dev_partialMax );
		break;
	case 1: // Exercice 2
		maxReduce_v1<<<dimGrid, dimBlock, sizeSMem>>>( n, dev_array, dev_partialMax );
		break;
	case 2: // Exercice 3
		maxReduce_v2<<<dimGrid, dimBlock, sizeSMem>>>( n, dev_array, dev_partialMax );
		break;
	case 3: // Exercice 4
		maxReduce_v3<<<dimGrid, dimBlock, sizeSMem>>>( n, dev_array, dev_partialMax );
		break;
	default: // Exercice 1
		break;
	}
	}
	chrGPU.stop();

	times.x = chrGPU.elapsedTime()/ (float)loop;
	
	// Get partial result from device to host
	HANDLE_ERROR( cudaMemcpy( host_partialMax, dev_partialMax,
				  sizePartial, cudaMemcpyDeviceToHost ) );
	
	ChronoCPU chrCPU;
	chrCPU.start();

	// Finish reduction on host
	res = maxRef( dimGrid, host_partialMax );

	chrCPU.stop();

	times.y = chrCPU.elapsedTime();

	return times;
}

#endif
